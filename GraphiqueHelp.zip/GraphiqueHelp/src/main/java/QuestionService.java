import java.util.List;

public class QuestionService {
    public List<Question> obtenirQuestions() {
        // Implementation to retrieve questions from the database
        return List.of(new Question());
    }
}
