import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.control.ListView;
import java.util.List;

public class EnseignantController {
    @FXML
    private ListView<Question> questionsListView;

    private final QuestionService questionService = new QuestionService();
    private final TestService testService = new TestService();

    @FXML
    private void initialize() {
        List<Question> questions = questionService.obtenirQuestions();
        questionsListView.getItems().addAll(questions);
    }

    @FXML
    private void handleCreerQuestion(ActionEvent event) {
        // Logic to handle question creation
    }

    @FXML
    private void handleCreerTest(ActionEvent event) {
        List<Question> selectedQuestions = questionsListView.getSelectionModel().getSelectedItems();
        Test test = testService.creerTest((TestService.List) selectedQuestions);
        testService.exporterTest(test, "test.txt", false);
        testService.exporterTest(test, "test_avec_reponses.txt", true);
    }
}
