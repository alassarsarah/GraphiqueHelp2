import java.util.ArrayList;
import java.util.List;

public class CustomList {
    private String listName;

    public CustomList(String listName) {
        this.listName = listName;
        List<Question> questions = new ArrayList<>(); // Initialize questions list
    }

    // Add other methods as needed
}
