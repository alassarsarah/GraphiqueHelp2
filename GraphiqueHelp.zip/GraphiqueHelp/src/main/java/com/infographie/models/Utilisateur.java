package com.infographie.models;

public class Utilisateur {
}
