import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class UtilisateurService {

    private final SessionFactory sessionFactory;

    public UtilisateurService() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }

    public void creerUtilisateur(Utilisateur utilisateur) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(utilisateur);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public Utilisateur obtenirUtilisateurParEmail(String email) {
        Session session = sessionFactory.openSession();
        try {
            Query<Utilisateur> query = session.createQuery("FROM Utilisateur WHERE email = :email", Utilisateur.class);
            query.setParameter("email", email);
            return query.uniqueResult();
        } finally {
            session.close();
        }
    }

    public Utilisateur seConnecter(String email, String motDePasse) {
        return null;
    }

    // Other CRUD methods...
}
