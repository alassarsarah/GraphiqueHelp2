import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    private final UtilisateurService utilisateurService = new UtilisateurService();

    @FXML
    private void handleLogin(ActionEvent event) {
        String email = emailField.getText();
        String motDePasse = passwordField.getText();
        Utilisateur utilisateur = utilisateurService.seConnecter(email, motDePasse);
        if (utilisateur != null) {
            // Redirect to appropriate dashboard based on user type
        } else {
            // Show error message
        }
    }
}
